public interface JogarComoMaquina {
    public int escolherJogo();
    public void EstrategiaMaq(JogoGeneral jogoG);
}
