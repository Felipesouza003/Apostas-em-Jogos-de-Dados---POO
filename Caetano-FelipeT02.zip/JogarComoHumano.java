public interface JogarComoHumano {
    public int escolherJogo();
    public void EscolherJogada(JogoGeneral jogoG);
}
