public interface Estatistica {
    
    final static short numfaces = 6;

    public void somaFaceSort(int n);
    public int[] getFacesSorteadasVet();
    public void printFacesSorteadas();
}