/*public interface Estatistica {

    static short numfaces = 6;
    static int[] faceSort = new int[6];


    public void somaFaceSort(int n);
    public int[] getFacesSorteadasVet();
    public void printFacesSorteadas();
}*/
