public interface JogarComoHumano {
    public char escolherJogo();
    public int EscolherJogada();
}
